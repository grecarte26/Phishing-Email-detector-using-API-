# -----------------------------------------------
# 🔄 Incident Review Assistant (GPT-4)
# Combines Phishing Email and Log File Analysis
# Created by Jerson Recarte for Dr. Jain's LLM course
# -----------------------------------------------

import os
import openai
import gradio as gr
from dotenv import load_dotenv

# 🔐 Load OpenAI API Key
load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise ValueError("OPENAI_API_KEY not found in .env file.")

client = openai.OpenAI(api_key=api_key)

# 🧠 Incident Review Prompt Function
def incident_analysis(email_text, log_text):
    email_summary = email_text.strip()
    log_summary = log_text.strip() if log_text else ""

    full_prompt = f"""You are a cybersecurity incident response assistant. You will receive:
- A suspicious email
- System or security logs

Your tasks:
1. Analyze the email and determine if it's a phishing attempt.
2. Review the logs for any follow-up malicious activity (e.g., failed logins, privilege escalation).
3. Reconstruct a short incident timeline.
4. Recommend immediate next steps for containment or further investigation.

---
Suspicious Email:
{email_summary}

---
Log Evidence:
{log_summary}

Now generate your report:
"""

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": full_prompt}],
        temperature=0.3
    )
    return response.choices[0].message.content.strip()

# 🧪 Example data for demo button
def load_example():
    example_email = (
        "From: alert@secure-verification.com\n"
        "Subject: Action Required – Password Reset\n\n"
        "Click here to verify: http://fake-login-alert.com\n"
        "Failure to verify will result in account suspension."
    )
    example_logs = (
        "Apr 21 14:22:10 host sshd[1022]: Failed password for user root from 203.0.113.10 port 3333 ssh2\n"
        "Apr 21 14:22:12 host sshd[1022]: Accepted password for user root from 203.0.113.10 port 3333 ssh2"
    )
    return [example_email, example_logs]

# 🌐 Gradio Interface
demo = gr.Interface(
    fn=incident_analysis,
    inputs=[
        gr.Textbox(
            lines=15,
            label="📨 Paste Suspicious Email Content Here",
            placeholder="e.g., fake login request, suspicious sender, or phishing message body"
        ),
        gr.Textbox(
            lines=10,
            label="📎 Paste Log Content (e.g., auth log, system activity)",
            placeholder="e.g., ssh login failures, sudo actions, file changes"
        )
    ],
    outputs=gr.Textbox(
        label="📄 GPT-Generated Incident Report",
        lines=25
    ),
    title="Incident Review Assistant",
    description="Paste a phishing email and related logs. GPT-4 will reconstruct the incident and suggest next steps.",
    examples=[load_example()],
    live=True
)

# 🚀 Launch the App
demo.launch()
