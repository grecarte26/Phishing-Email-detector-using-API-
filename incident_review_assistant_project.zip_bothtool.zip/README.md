# 🔄 Incident Review Assistant (GPT-4)

**Created by:** Jerson Recarte  
**For:** Dr. Jain – LLM Course in Digital Forensics & Cybersecurity

---

## 🧭 Project Purpose

This tool extends the original **Phishing Email Detection** project by simulating a real-world forensic workflow:
1. Detect phishing email content
2. Analyze associated log activity (e.g., login attempts)
3. Reconstruct a timeline
4. Suggest next steps for containment and investigation

---

## 🧰 How It Works

- Paste a suspicious email in the text field
- Paste related logs (auth logs, system logs, etc.) in the second field
- GPT-4 returns:
  - Summary of the email
  - Suspicious activity in logs
  - Reconstructed narrative
  - Recommendations

---

## 🧪 Example Use Case

**Email:**
```
From: alert@secure-verification.com
Subject: Action Required – Password Reset
Click to verify: http://fake-login-alert.com
```

**Logs:**
```
Failed login for root from 203.0.113.10
Followed by successful login for same IP
```

GPT Response:
- Flags phishing content
- Identifies brute-force compromise
- Suggests disabling user, alerting SOC, and checking lateral movement

---

## 🚀 Setup Instructions

1. Clone the repository or unzip
2. Install dependencies:
```bash
pip install openai gradio python-dotenv
```
3. Create a `.env` file:
```
OPENAI_API_KEY=sk-your-key-here
```
4. Run the tool:
```bash
python incident_review_assistant.py
```

---

## 🧠 Educational Value

This project complements the original **Phishing Detector** by adding a forensic log layer. It helps students connect:
- Social engineering entry point ➡️ System intrusion trail
- Narrative building ➡️ Incident report generation

Perfect for teaching chain-of-events reasoning in forensic response.

---

*Made with ❤️ by Jerson Recarte*
